@echo off
title Python Automation Toolkit
cd /d "%~dp0scripts"
echo.
echo   ===========================================
echo     PYTHON AUTOMATION TOOLKIT
echo     12 Scripts That Save Hours Each Week
echo   ===========================================
echo.
echo   [1]  Bulk File Renamer
echo   [2]  PDF Merger
echo   [3]  Duplicate File Finder
echo   [4]  Image Batch Resizer
echo   [5]  CSV / Excel to JSON
echo   [6]  Invoice PDF Generator
echo   [7]  Folder Organizer
echo   [8]  Text Search &amp; Replace
echo   [9]  Automated Backup
echo   [10] Screenshot Organizer
echo   [11] Excel File Combiner
echo   [12] Web Table Scraper
echo.
echo   [0]  Exit
echo.
set /p choice="  Choose a tool (0-12): "

if "%choice%"=="1" python bulk_rename.py
if "%choice%"=="2" python pdf_merge.py
if "%choice%"=="3" python duplicate_finder.py
if "%choice%"=="4" python image_resize.py
if "%choice%"=="5" python csv_to_json.py
if "%choice%"=="6" python invoice_gen.py
if "%choice%"=="7" python folder_organizer.py
if "%choice%"=="8" python text_replace.py
if "%choice%"=="9" python backup_folders.py
if "%choice%"=="10" python screenshot_sort.py
if "%choice%"=="11" python excel_combine.py
if "%choice%"=="12" python web_scraper.py
if "%choice%"=="0" exit
