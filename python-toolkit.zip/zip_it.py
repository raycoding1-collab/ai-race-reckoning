import zipfile, os
os.chdir(r'C:\Users\Lenovo\python-automation-toolkit')
with zipfile.ZipFile('python-automation-toolkit.zip','w',zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk('.'):
        for f in files:
            if f.endswith('.zip'): continue
            path = os.path.join(root, f)
            z.write(path)
            print(f'  {path}')
size = os.path.getsize('python-automation-toolkit.zip')
print(f'\nZIP: {size} bytes ({size/1024:.1f} KB)')
