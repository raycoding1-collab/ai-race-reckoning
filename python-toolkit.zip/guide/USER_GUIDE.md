# Python Automation Toolkit — User Guide

## Welcome

You now own 12 ready-to-run Python scripts that automate the most common, time-consuming computer tasks. No programming knowledge needed. Each script has a friendly text interface — just double-click and follow the prompts.

## Getting Started

### Requirements
- **Windows 10 or 11** (Mac/Linux version coming soon)
- **Python 3.8+** installed — [Download from python.org](https://python.org) (check "Add to PATH" during install)

### How to Run

**Option A — Use the Menu (recommended)**
Double-click `menu.bat` in the `launchers` folder. Choose a tool from the numbered list.

**Option B — Run directly**
Double-click any `.py` script in the `scripts` folder. A terminal window opens with instructions.

### First-Time Setup
Some scripts auto-install required libraries (Pillow, PyPDF2, openpyxl, requests, beautifulsoup4). If you see "Installing required library..." — that's normal. It only happens once.

---

## The 12 Tools

### 1. Bulk File Renamer (`bulk_rename.py`)
**Problem:** You have 200 photos named "IMG_0001.jpg" and need them organized.
**What it does:** Rename hundreds of files at once — find-and-replace, numbered sequences, or add prefixes/suffixes.
**Time saved:** 30+ minutes per batch

### 2. PDF Merger (`pdf_merge.py`)
**Problem:** You have 5 PDF reports and need one combined file.
**What it does:** Select PDF files, pick the order, get a single merged PDF. Shows file sizes so you know what you're combining.
**Time saved:** 10+ minutes per merge

### 3. Duplicate File Finder (`duplicate_finder.py`)
**Problem:** Your hard drive is full of copies and you don't know which files are duplicates.
**What it does:** Scans folders using SHA-256 hash comparison. Shows duplicate groups with sizes. Optionally deletes copies while keeping originals.
**Time saved:** Hours of manual checking

### 4. Image Batch Resizer (`image_resize.py`)
**Problem:** Photos are too large for email or web upload.
**What it does:** Resize multiple images at once. Set max width/height or percentage. Keeps aspect ratio. Saves to a "resized" subfolder.
**Time saved:** 20+ minutes per batch

### 5. CSV/Excel to JSON (`csv_to_json.py`)
**Problem:** You need data in JSON format for a website or API but only have spreadsheets.
**What it does:** Converts CSV or Excel files to formatted JSON. Handles multiple sheets.
**Time saved:** 15+ minutes per conversion

### 6. Invoice PDF Generator (`invoice_gen.py`)
**Problem:** Creating invoices manually in Word/Google Docs is slow and inconsistent.
**What it does:** Generate professional PDF invoices from a simple CSV. One row per line item. Styled with purple header, auto-calculated totals.
**Time saved:** 30+ minutes per batch of invoices

### 7. Folder Organizer (`folder_organizer.py`)
**Problem:** Your Downloads folder has 500 files of every type mixed together.
**What it does:** Sorts files into categorized subfolders — Images, Documents, Archives, Audio, Video, Code, Fonts. You preview before anything moves.
**Time saved:** 20+ minutes per folder

### 8. Text Search & Replace (`text_replace.py`)
**Problem:** You need to update a URL or copyright year across 50 files in a project.
**What it does:** Find and replace text across multiple files. Creates automatic backups before any changes. Case-sensitive or insensitive.
**Time saved:** 30+ minutes per project

### 9. Automated Backup (`backup_folders.py`)
**Problem:** You forget to back up important folders and worry about losing data.
**What it does:** Creates timestamped ZIP archives of selected folders. Run weekly for peace of mind.
**Time saved:** Prevents catastrophic data loss

### 10. Screenshot Organizer (`screenshot_sort.py`)
**Problem:** Your Screenshots folder has 2 years of unsorted captures.
**What it does:** Sorts screenshots into Year-Month folders based on file creation date. Handles Windows, Mac, and browser screenshots.
**Time saved:** 15+ minutes per cleanup

### 11. Excel File Combiner (`excel_combine.py`)
**Problem:** You have monthly reports in separate Excel files and need them combined.
**What it does:** Combine multiple Excel files into one. Each file becomes a sheet, or all data merged into one sheet with source tracking.
**Time saved:** 20+ minutes per combination

### 12. Web Table Scraper (`web_scraper.py`)
**Problem:** You need data from a Wikipedia table or any webpage table in spreadsheet format.
**What it does:** Paste a URL, see available tables, save any as CSV. Works on Wikipedia, government data, sports stats, and more.
**Time saved:** 15+ minutes per extraction

---

## Tips

- **Drag & drop folders** into the terminal window instead of typing paths
- **All scripts create backups** before modifying files (where applicable)
- **Test on a copy** of important data the first time you use a tool
- **Run from the menu** (`menu.bat`) for the easiest experience

## Support

Questions? Issues? Email: raycoding1@gmail.com

---

*Python Automation Toolkit v1.0 — May 2026*
*12 scripts. Zero coding required. Hours saved every week.*
