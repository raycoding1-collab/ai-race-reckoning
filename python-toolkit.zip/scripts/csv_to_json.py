"""
CSV TO JSON CONVERTER
Convert CSV/Excel files to JSON format. Useful for web developers,
data analysis, or preparing data for APIs.

Usage: Select a CSV or Excel file, get a formatted JSON file.
"""
import os, sys, csv, json

def convert_csv_to_json(csv_path, output_path):
    """Convert a CSV file to JSON array of objects."""
    data = []
    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Clean up keys
            cleaned = {k.strip(): v.strip() for k, v in row.items()}
            data.append(cleaned)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    return len(data)

def convert_excel_to_json(xlsx_path, output_path):
    """Convert an Excel file to JSON."""
    try:
        import openpyxl
    except ImportError:
        print("Installing required library: openpyxl")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "openpyxl", "-q"])
        import openpyxl
    
    wb = openpyxl.load_workbook(xlsx_path, read_only=True)
    all_data = {}
    
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue
        headers = [str(h) if h else f"col_{i}" for i, h in enumerate(rows[0])]
        sheet_data = []
        for row in rows[1:]:
            obj = {headers[i]: str(v) if v is not None else "" for i, v in enumerate(row)}
            sheet_data.append(obj)
        all_data[sheet_name] = sheet_data
    
    wb.close()
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(all_data, f, indent=2, ensure_ascii=False)
    
    return sum(len(v) for v in all_data.values())

def main():
    print("=" * 55)
    print("  CSV / EXCEL TO JSON CONVERTER")
    print("=" * 55)
    print()
    
    file_path = input("CSV or Excel file path (drag here): ").strip().strip('"')
    if not os.path.isfile(file_path):
        print("ERROR: File not found.")
        sys.exit(1)
    
    ext = os.path.splitext(file_path)[1].lower()
    output_path = os.path.splitext(file_path)[0] + ".json"
    
    print(f"\nConverting: {os.path.basename(file_path)}")
    
    if ext in ('.csv', '.tsv', '.txt'):
        rows = convert_csv_to_json(file_path, output_path)
    elif ext in ('.xlsx', '.xlsm'):
        rows = convert_excel_to_json(file_path, output_path)
    else:
        print(f"Unsupported format: {ext}. Please use CSV or XLSX.")
        sys.exit(1)
    
    size_kb = os.path.getsize(output_path) / 1024
    print(f"\nConverted {rows} rows.")
    print(f"JSON saved to: {output_path} ({size_kb:.0f} KB)")
    
    # Show preview
    with open(output_path, 'r', encoding='utf-8') as f:
        preview = f.read(500)
    print(f"\nPreview:\n{preview}...")
    
    os.startfile(os.path.dirname(output_path))
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
