"""
EXCEL FILE COMBINER
Combine multiple Excel files into one spreadsheet.
Each source file becomes a sheet, or all data merged into one sheet.

Usage: Select folder with Excel files, choose merge mode.
"""
import os, sys

try:
    import openpyxl
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "openpyxl", "-q"])
    import openpyxl

def merge_to_sheets(folder, output_path):
    """Each Excel file -> one sheet."""
    wb_out = openpyxl.Workbook()
    wb_out.remove(wb_out.active)
    files = sorted([f for f in os.listdir(folder) if f.endswith(('.xlsx','.xlsm'))])
    for fname in files:
        fpath = os.path.join(folder, fname)
        wb_src = openpyxl.load_workbook(fpath, read_only=True)
        for sname in wb_src.sheetnames:
            ws_src = wb_src[sname]
            sheet_title = f"{os.path.splitext(fname)[0]}_{sname}"[:31]
            ws_out = wb_out.create_sheet(title=sheet_title)
            for row in ws_src.iter_rows(values_only=True):
                ws_out.append(list(row))
        wb_src.close()
        print(f"  Added: {fname}")
    wb_out.save(output_path)
    return len(files)

def merge_to_one(folder, output_path):
    """All data merged into one sheet with source column."""
    wb_out = openpyxl.Workbook()
    ws_out = wb_out.active
    ws_out.title = "Combined"
    ws_out.append(["Source File", "Sheet"] + [f"Col_{i}" for i in range(1, 20)])
    files = sorted([f for f in os.listdir(folder) if f.endswith(('.xlsx','.xlsm'))])
    for fname in files:
        fpath = os.path.join(folder, fname)
        wb_src = openpyxl.load_workbook(fpath, read_only=True)
        for sname in wb_src.sheetnames:
            ws_src = wb_src[sname]
            rows = list(ws_src.iter_rows(values_only=True))
            for row in rows[1:]:
                ws_out.append([fname, sname] + list(row))
        wb_src.close()
        print(f"  Merged: {fname}")
    wb_out.save(output_path)
    return len(files)

def main():
    print("=" * 55)
    print("  EXCEL FILE COMBINER")
    print("=" * 55)
    print()
    folder = input("Folder with Excel files: ").strip().strip('"')
    if not os.path.isdir(folder):
        print("ERROR: Not a valid folder."); sys.exit(1)
    print("\nMode: 1) Each file = separate sheet  2) All merged into one sheet")
    mode = input("Choice (1-2): ").strip()
    output = os.path.join(folder, "combined.xlsx")
    if mode == "1":
        n = merge_to_sheets(folder, output)
    else:
        n = merge_to_one(folder, output)
    print(f"\n{n} file(s) combined into: {output}")
    os.startfile(os.path.dirname(output))
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
