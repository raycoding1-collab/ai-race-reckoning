"""
SCREENSHOT ORGANIZER
Sort screenshots into date folders (Year-Month).
"""
import os, sys, shutil
from datetime import datetime

PATTERNS = ['screenshot', 'screen shot', 'snip', 'capture', 'clipboard', 'snapshot', 'printscreen']

def is_ss(fname):
    return any(p in fname.lower() for p in PATTERNS)

def get_date(filepath):
    try:
        ts = os.stat(filepath).st_birthtime if hasattr(os.stat, 'st_birthtime') else os.stat(filepath).st_ctime
    except:
        ts = os.stat(filepath).st_mtime
    return datetime.fromtimestamp(ts).strftime("%Y-%m")

def main():
    print("=" * 55)
    print("  SCREENSHOT ORGANIZER")
    print("=" * 55)
    print()
    folder = input("Screenshots folder: ").strip().strip('"')
    if not os.path.isdir(folder):
        print("ERROR: Not a valid folder.")
        sys.exit(1)
    imgs = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}
    screenshots = []
    for fname in os.listdir(folder):
        fpath = os.path.join(folder, fname)
        if not os.path.isfile(fpath): continue
        if os.path.splitext(fname)[1].lower() in imgs:
            if is_ss(fname): screenshots.append(fpath)
    if not screenshots:
        all_imgs = [os.path.join(folder,f) for f in os.listdir(folder) if os.path.isfile(os.path.join(folder,f)) and os.path.splitext(f)[1].lower() in imgs]
        if all_imgs and input(f"No screenshot-named files found. Organize all {len(all_imgs)} images? (y/n): ").strip().lower()=='y':
            screenshots = all_imgs
    if not screenshots:
        print("No screenshots found."); sys.exit(0)
    groups = {}
    for fp in screenshots:
        dk = get_date(fp)
        groups.setdefault(dk, []).append(fp)
    for dk in sorted(groups): print(f"  {dk}: {len(groups[dk])} files")
    if input(f"\nOrganize into {len(groups)} folders? (y/n): ").strip().lower() != 'y':
        print("Cancelled."); sys.exit(0)
    moved = 0
    for dk, files in groups.items():
        dd = os.path.join(folder, dk)
        os.makedirs(dd, exist_ok=True)
        for fp in files:
            shutil.move(fp, os.path.join(dd, os.path.basename(fp))); moved += 1
    print(f"\n{moved} screenshots organized.")
    os.startfile(folder)
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
