"""
BULK FILE RENAMER
Rename multiple files at once using find-and-replace or numbered sequences.
Double-click to run — follow the prompts.

Examples:
  - Replace "Draft" with "Final" in all filenames
  - Rename photos to "Vacation_001.jpg", "Vacation_002.jpg", etc.
  - Add a prefix like "2026_" to all files in a folder
"""
import os, sys

def get_folder():
    folder = input("Folder path (drag folder here or type path): ").strip().strip('"')
    if not os.path.isdir(folder):
        print(f"ERROR: '{folder}' is not a valid folder.")
        sys.exit(1)
    return folder

def rename_replace(folder, old_text, new_text):
    """Replace text in all filenames."""
    renamed = 0
    for fname in os.listdir(folder):
        if old_text in fname:
            old_path = os.path.join(folder, fname)
            new_name = fname.replace(old_text, new_text)
            new_path = os.path.join(folder, new_name)
            os.rename(old_path, new_path)
            print(f"  {fname}  ->  {new_name}")
            renamed += 1
    print(f"\n{renamed} file(s) renamed.")

def rename_sequence(folder, prefix, start_num=1):
    """Rename files in numbered sequence."""
    files = [f for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))]
    files.sort()
    renamed = 0
    for i, fname in enumerate(files, start=start_num):
        ext = os.path.splitext(fname)[1]
        new_name = f"{prefix}_{i:03d}{ext}"
        old_path = os.path.join(folder, fname)
        new_path = os.path.join(folder, new_name)
        os.rename(old_path, new_path)
        print(f"  {fname}  ->  {new_name}")
        renamed += 1
    print(f"\n{renamed} file(s) renamed.")

def add_prefix_suffix(folder, prefix="", suffix=""):
    """Add prefix and/or suffix to all filenames."""
    renamed = 0
    for fname in os.listdir(folder):
        old_path = os.path.join(folder, fname)
        if not os.path.isfile(old_path):
            continue
        name, ext = os.path.splitext(fname)
        new_name = f"{prefix}{name}{suffix}{ext}"
        new_path = os.path.join(folder, new_name)
        os.rename(old_path, new_path)
        print(f"  {fname}  ->  {new_name}")
        renamed += 1
    print(f"\n{renamed} file(s) renamed.")

def main():
    print("=" * 55)
    print("  BULK FILE RENAMER")
    print("=" * 55)
    print()
    folder = get_folder()
    
    print("\nOptions:")
    print("  1. Find & Replace text in filenames")
    print("  2. Rename in numbered sequence")
    print("  3. Add prefix / suffix")
    choice = input("\nChoice (1-3): ").strip()
    
    if choice == "1":
        old = input("Text to find: ").strip()
        new = input("Replace with: ").strip()
        rename_replace(folder, old, new)
    elif choice == "2":
        prefix = input("Base name (e.g., 'Vacation'): ").strip()
        start = input("Start number (default 1): ").strip()
        start = int(start) if start else 1
        rename_sequence(folder, prefix, start)
    elif choice == "3":
        prefix = input("Prefix to add (or Enter to skip): ").strip()
        suffix = input("Suffix to add (or Enter to skip): ").strip()
        add_prefix_suffix(folder, prefix, suffix)
    else:
        print("Invalid choice.")
    
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
