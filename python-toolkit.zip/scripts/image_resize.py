"""
IMAGE BATCH RESIZER
Resize multiple images at once. Set max width/height or percentage.
Common uses: prepare photos for email, web upload, or social media.

Supports: JPG, PNG, GIF, BMP, WebP
"""
import os, sys

try:
    from PIL import Image
except ImportError:
    print("Installing required library: Pillow")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "Pillow", "-q"])
    from PIL import Image

def get_images(folder):
    """Find all image files in a folder."""
    exts = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}
    images = []
    for fname in os.listdir(folder):
        ext = os.path.splitext(fname)[1].lower()
        if ext in exts:
            images.append(os.path.join(folder, fname))
    return sorted(images)

def resize_by_max(img, max_width, max_height):
    """Resize keeping aspect ratio, fitting within max dimensions."""
    w, h = img.size
    ratio = min(max_width / w, max_height / h)
    if ratio < 1:
        return img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)
    return img

def resize_by_percent(img, percent):
    """Resize by percentage."""
    w, h = img.size
    new_w, new_h = int(w * percent / 100), int(h * percent / 100)
    return img.resize((new_w, new_h), Image.LANCZOS)

def main():
    print("=" * 55)
    print("  IMAGE BATCH RESIZER")
    print("=" * 55)
    print()
    
    folder = input("Folder with images (drag here): ").strip().strip('"')
    if not os.path.isdir(folder):
        print("ERROR: Not a valid folder.")
        sys.exit(1)
    
    images = get_images(folder)
    if not images:
        print("No image files found (JPG, PNG, GIF, BMP, WebP).")
        sys.exit(1)
    
    print(f"\nFound {len(images)} image(s).")
    
    print("\nResize method:")
    print("  1. Set max width & height (keeps aspect ratio)")
    print("  2. Resize by percentage")
    choice = input("Choice (1-2): ").strip()
    
    # Create output folder
    output_folder = os.path.join(folder, "resized")
    os.makedirs(output_folder, exist_ok=True)
    
    resized = 0
    for img_path in images:
        try:
            img = Image.open(img_path)
            fname = os.path.basename(img_path)
            
            if choice == "1":
                max_w = int(input(f"\nMax width for all images (e.g., 1200): "))
                max_h = int(input(f"Max height for all images (e.g., 800): "))
                new_img = resize_by_max(img, max_w, max_h)
            else:
                pct = int(input(f"\nResize to what percent? (e.g., 50 for half size): "))
                new_img = resize_by_percent(img, pct)
            
            out_path = os.path.join(output_folder, fname)
            new_img.save(out_path, quality=85)
            print(f"  Resized: {fname} ({img.size} -> {new_img.size})")
            resized += 1
            break  # Ask dimensions once for all
        except Exception as e:
            print(f"  Error with {fname}: {e}")
    
    # Process with same settings
    if resized == 1:
        max_w = int(input(f"\nMax width: ")) if choice == "1" else 0
        max_h = int(input(f"Max height: ")) if choice == "1" else 0
        pct = int(input(f"Percent: ")) if choice == "2" else 0
        
        for img_path in images[1:]:
            try:
                img = Image.open(img_path)
                fname = os.path.basename(img_path)
                if choice == "1":
                    new_img = resize_by_max(img, max_w, max_h)
                else:
                    new_img = resize_by_percent(img, pct)
                out_path = os.path.join(output_folder, fname)
                new_img.save(out_path, quality=85)
                print(f"  Resized: {fname}")
                resized += 1
            except Exception as e:
                print(f"  Error with {fname}: {e}")
    
    print(f"\n{resized} image(s) resized.")
    print(f"Saved to: {output_folder}")
    os.startfile(output_folder)
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
