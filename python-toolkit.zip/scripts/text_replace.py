"""
TEXT SEARCH & REPLACE ACROSS FILES
Find and replace text across multiple files at once.
Useful for updating URLs, copyright years, or variable names across a project.

Usage: Select a folder, enter find/replace text, and all matching files are updated.
Backup copies are saved automatically before any changes.
"""
import os, sys, shutil
from datetime import datetime

TEXT_EXTS = {'.txt', '.html', '.css', '.js', '.py', '.json', '.xml', '.md', '.csv', '.yaml', '.yml', '.ini', '.cfg', '.log', '.bat', '.sh', '.ps1', '.sql', '.java', '.cpp', '.c', '.h', '.rs', '.go', '.ts', '.jsx', '.tsx', '.vue', '.php', '.rb'}

def search_and_replace(filepath, find_text, replace_text, backup_dir, case_sensitive):
    """Search and replace in a single file. Return number of replacements."""
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
    except:
        return 0
    
    if case_sensitive:
        if find_text not in content:
            return 0
        count = content.count(find_text)
        new_content = content.replace(find_text, replace_text)
    else:
        content_lower = content.lower()
        find_lower = find_text.lower()
        if find_lower not in content_lower:
            return 0
        count = content_lower.count(find_lower)
        # Case-insensitive replace
        import re
        new_content = re.sub(re.escape(find_text), replace_text, content, flags=re.IGNORECASE)
    
    # Backup original
    rel_path = filepath.replace(os.path.dirname(backup_dir), "").lstrip(os.sep)
    backup_path = os.path.join(backup_dir, rel_path)
    os.makedirs(os.path.dirname(backup_path), exist_ok=True)
    shutil.copy2(filepath, backup_path)
    
    # Write modified
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    return count

def main():
    print("=" * 55)
    print("  TEXT SEARCH & REPLACE")
    print("=" * 55)
    print()
    
    folder = input("Folder to search in (drag here): ").strip().strip('"')
    if not os.path.isdir(folder):
        print("ERROR: Not a valid folder.")
        sys.exit(1)
    
    find_text = input("\nText to FIND: ")
    if not find_text:
        print("No search text entered.")
        sys.exit(1)
    
    replace_text = input("Replace WITH: ")
    case_sensitive = input("Case sensitive? (y/n, default y): ").strip().lower() != 'n'
    
    # Create backup directory
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(folder, f"backup_{timestamp}")
    
    print(f"\nScanning files...")
    modified = 0
    total_replacements = 0
    
    for root, dirs, files in os.walk(folder):
        # Skip backup dirs
        dirs[:] = [d for d in dirs if not d.startswith('backup_')]
        
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in TEXT_EXTS:
                continue
            
            filepath = os.path.join(root, fname)
            count = search_and_replace(filepath, find_text, replace_text, backup_dir, case_sensitive)
            if count > 0:
                rel = os.path.relpath(filepath, folder)
                print(f"  {rel}: {count} replacement(s)")
                modified += 1
                total_replacements += count
    
    print(f"\nResults:")
    print(f"  Files modified: {modified}")
    print(f"  Total replacements: {total_replacements}")
    print(f"  Backups saved to: {backup_dir}")
    
    if modified == 0:
        print(f"\n  Text '{find_text}' not found in any supported files.")
    
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
