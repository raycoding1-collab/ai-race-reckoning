"""
FOLDER ORGANIZER
Automatically sort messy folders by file type.
Moves files into categorized subfolders: Images, Documents, Archives, Audio, Video, Code, etc.

Usage: Point at any messy folder. Files get sorted into organized subfolders.
"""
import os, sys, shutil

CATEGORIES = {
    "Images": {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".ico"},
    "Documents": {".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".xls", ".xlsx", ".ppt", ".pptx", ".csv"},
    "Archives": {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"},
    "Audio": {".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a"},
    "Video": {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm"},
    "Code": {".py", ".js", ".html", ".css", ".json", ".xml", ".yaml", ".yml", ".sh", ".bat", ".ps1", ".java", ".cpp", ".c", ".h", ".rs", ".go", ".ts", ".jsx", ".tsx", ".vue", ".sql"},
    "Fonts": {".ttf", ".otf", ".woff", ".woff2"},
    "Other": set()
}

def get_category(ext):
    for cat, exts in CATEGORIES.items():
        if ext in exts:
            return cat
    return "Other"

def main():
    print("=" * 55)
    print("  FOLDER ORGANIZER")
    print("=" * 55)
    print()
    
    folder = input("Folder to organize (drag here): ").strip().strip('"')
    if not os.path.isdir(folder):
        print("ERROR: Not a valid folder.")
        sys.exit(1)
    
    # Preview first
    moves = []
    for fname in os.listdir(folder):
        fpath = os.path.join(folder, fname)
        if not os.path.isfile(fpath):
            continue
        ext = os.path.splitext(fname)[1].lower()
        cat = get_category(ext)
        dest = os.path.join(folder, cat)
        moves.append((fpath, dest, fname))
    
    if not moves:
        print("No files to organize.")
        sys.exit(0)
    
    # Count by category
    from collections import Counter
    counts = Counter(cat for _, cat, _ in moves)
    print(f"Found {len(moves)} file(s):")
    for cat, n in sorted(counts.items()):
        print(f"  {cat}: {n} file(s)")
    
    confirm = input(f"\nOrganize these files into subfolders? (yes/no): ").strip().lower()
    if confirm not in ('yes', 'y'):
        print("Cancelled.")
        sys.exit(0)
    
    organized = 0
    for fpath, dest_dir, fname in moves:
        os.makedirs(dest_dir, exist_ok=True)
        dest_path = os.path.join(dest_dir, fname)
        # Handle name collisions
        if os.path.exists(dest_path):
            name, ext = os.path.splitext(fname)
            dest_path = os.path.join(dest_dir, f"{name}_copy{ext}")
        shutil.move(fpath, dest_path)
        print(f"  {fname} -> {os.path.basename(dest_dir)}/")
        organized += 1
    
    print(f"\n{organized} file(s) organized into {len(counts)} folder(s).")
    os.startfile(folder)
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
