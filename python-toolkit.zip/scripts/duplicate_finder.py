"""
DUPLICATE FILE FINDER
Scan a folder and find duplicate files based on content (hash comparison).
Shows which files are identical so you can safely delete copies.

Usage: Select a folder, see duplicates grouped together.
"""
import os, sys, hashlib
from collections import defaultdict

def hash_file(filepath, block_size=65536):
    """Get SHA-256 hash of a file."""
    sha = hashlib.sha256()
    try:
        with open(filepath, 'rb') as f:
            for block in iter(lambda: f.read(block_size), b''):
                sha.update(block)
        return sha.hexdigest()
    except (PermissionError, OSError):
        return None

def scan_folder(folder):
    """Scan folder and group files by hash."""
    print(f"Scanning: {folder}")
    hash_map = defaultdict(list)
    total = 0
    scanned = 0
    
    for root, dirs, files in os.walk(folder):
        for fname in files:
            total += 1
    
    for root, dirs, files in os.walk(folder):
        for fname in files:
            filepath = os.path.join(root, fname)
            size_mb = os.path.getsize(filepath) / (1024 * 1024)
            # Skip very large files for speed
            if size_mb > 100:
                continue
            fhash = hash_file(filepath)
            if fhash:
                hash_map[fhash].append(filepath)
            scanned += 1
            if scanned % 50 == 0:
                print(f"  Scanned {scanned}/{total} files...")
    
    return hash_map

def main():
    print("=" * 55)
    print("  DUPLICATE FILE FINDER")
    print("=" * 55)
    print()
    
    folder = input("Folder to scan (drag here): ").strip().strip('"')
    if not os.path.isdir(folder):
        print("ERROR: Not a valid folder.")
        sys.exit(1)
    
    hash_map = scan_folder(folder)
    
    # Find duplicates
    duplicates = {h: paths for h, paths in hash_map.items() if len(paths) > 1}
    
    if not duplicates:
        print("\nNo duplicate files found.")
        input("\nPress Enter to exit...")
        return
    
    print(f"\n{'='*55}")
    print(f"  FOUND {sum(len(v)-1 for v in duplicates.values())} DUPLICATE FILES")
    print(f"  in {len(duplicates)} groups")
    print(f"{'='*55}")
    
    total_wasted = 0
    for i, (fhash, paths) in enumerate(duplicates.items(), 1):
        size = os.path.getsize(paths[0])
        wasted = size * (len(paths) - 1)
        total_wasted += wasted
        print(f"\nGroup {i}: {len(paths)} identical copies ({size/1024:.0f} KB each)")
        for p in paths:
            print(f"  {'[KEEP]' if p == paths[0] else '[DEL?]'} {p}")
    
    print(f"\nTotal space that could be freed: {total_wasted/(1024*1024):.1f} MB")
    
    delete = input("\nDelete duplicates (keeping first copy)? Type YES to confirm: ").strip()
    if delete.upper() == "YES":
        deleted = 0
        for fhash, paths in duplicates.items():
            for p in paths[1:]:  # Keep first, delete rest
                try:
                    os.remove(p)
                    print(f"  Deleted: {os.path.basename(p)}")
                    deleted += 1
                except:
                    print(f"  Could not delete: {os.path.basename(p)}")
        print(f"\n{deleted} duplicate(s) deleted.")
    
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
