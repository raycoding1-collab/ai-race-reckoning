"""
AUTOMATED FOLDER BACKUP
Create timestamped ZIP backups of important folders.
"""
import os, sys, zipfile
from datetime import datetime

def backup_folder(source_folder, dest_folder, folder_name=""):
    if not folder_name:
        folder_name = os.path.basename(source_folder.rstrip(os.sep))
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_name = f"{folder_name}_{timestamp}.zip"
    zip_path = os.path.join(dest_folder, zip_name)
    print(f"  Backing up: {source_folder}")
    file_count = 0
    total_size = 0
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source_folder):
            for fname in files:
                filepath = os.path.join(root, fname)
                arcname = os.path.relpath(filepath, source_folder)
                try:
                    zf.write(filepath, arcname)
                    file_count += 1
                    total_size += os.path.getsize(filepath)
                except: pass
    zip_size = os.path.getsize(zip_path)
    print(f"    {file_count} files ({total_size/(1024*1024):.1f}MB -> {zip_size/(1024*1024):.1f}MB)")
    return zip_path

def main():
    print("=" * 55)
    print("  AUTOMATED FOLDER BACKUP")
    print("=" * 55)
    print()
    dest = input("Backup destination folder: ").strip().strip('"')
    if not os.path.isdir(dest):
        os.makedirs(dest, exist_ok=True)
    print("\nEnter folder paths to back up (blank line to finish):")
    folders = []
    while True:
        f = input("> ").strip().strip('"')
        if not f: break
        if os.path.isdir(f): folders.append(f)
        else: print(f"  Not a folder: {f}")
    if not folders:
        print("No folders selected.")
        sys.exit(0)
    print(f"\nBacking up {len(folders)} folder(s)...")
    for folder in folders:
        backup_folder(folder, dest)
    print(f"\nDone. Saved to: {dest}")
    os.startfile(dest)
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
