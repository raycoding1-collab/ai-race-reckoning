"""
WEB TABLE SCRAPER
Extract tables from any webpage and save as CSV.
No coding required — just paste a URL and pick a table.

Usage: Paste URL, see available tables, save as CSV.
"""
import os, sys, csv

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "beautifulsoup4", "-q"])
    import requests
    from bs4 import BeautifulSoup

def scrape_tables(url):
    """Extract all HTML tables from a URL."""
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
    try:
        resp = requests.get(url, headers=headers, timeout=15)
        resp.raise_for_status()
    except Exception as e:
        print(f"ERROR fetching URL: {e}")
        return None
    soup = BeautifulSoup(resp.text, 'html.parser')
    tables = soup.find_all('table')
    return tables

def table_to_csv(table):
    """Convert HTML table to list of lists."""
    rows = []
    for tr in table.find_all('tr'):
        row = []
        for cell in tr.find_all(['td', 'th']):
            row.append(cell.get_text(strip=True))
        if row:
            rows.append(row)
    return rows

def main():
    print("=" * 55)
    print("  WEB TABLE SCRAPER")
    print("=" * 55)
    print()
    url = input("Webpage URL: ").strip()
    if not url.startswith('http'):
        url = 'https://' + url
    print(f"\nFetching: {url}")
    tables = scrape_tables(url)
    if not tables:
        print("No tables found on this page.")
        input("\nPress Enter to exit...")
        return
    print(f"\nFound {len(tables)} table(s):")
    for i, table in enumerate(tables):
        rows = table.find_all('tr')
        cols = len(rows[0].find_all(['td','th'])) if rows else 0
        preview = table.get_text(strip=True)[:80]
        print(f"  [{i+1}] {len(rows)} rows x {cols} cols — {preview}...")
    choice = input(f"\nWhich table to save? (1-{len(tables)}, or 'all'): ").strip().lower()
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    if choice == 'all':
        for i, table in enumerate(tables):
            data = table_to_csv(table)
            out = os.path.join(desktop, f"table_{i+1}.csv")
            with open(out, 'w', newline='', encoding='utf-8-sig') as f:
                csv.writer(f).writerows(data)
            print(f"  Saved: table_{i+1}.csv ({len(data)} rows)")
    else:
        try:
            idx = int(choice) - 1
            data = table_to_csv(tables[idx])
            out = os.path.join(desktop, "scraped_table.csv")
            with open(out, 'w', newline='', encoding='utf-8-sig') as f:
                csv.writer(f).writerows(data)
            print(f"Saved: {out} ({len(data)} rows)")
        except:
            print("Invalid choice.")
    os.startfile(desktop)
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
