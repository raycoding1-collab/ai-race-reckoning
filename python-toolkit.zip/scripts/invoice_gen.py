"""
INVOICE PDF GENERATOR
Generate professional PDF invoices from a simple CSV file.
Each row in the CSV becomes one invoice.

CSV format: client_name, client_email, item, quantity, unit_price, date, invoice_number
"""
import os, sys, csv
from datetime import datetime

def create_invoice_html(client_name, client_email, items, invoice_num, date_str):
    """Generate an invoice as HTML (then convert to PDF)."""
    total = sum(qty * price for _, qty, price in items)
    
    items_html = ""
    for item, qty, price in items:
        line_total = qty * price
        items_html += f"""
        <tr>
            <td>{item}</td>
            <td style="text-align:center">{qty}</td>
            <td style="text-align:right">${price:.2f}</td>
            <td style="text-align:right">${line_total:.2f}</td>
        </tr>"""
    
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
body{{font-family:Arial,sans-serif;padding:40px;color:#333}}
.header{{border-bottom:2px solid #6c5ce7;padding-bottom:15px;margin-bottom:30px}}
.header h1{{color:#6c5ce7;margin:0}}
.invoice-info{{display:flex;justify-content:space-between;margin-bottom:30px}}
table{{width:100%;border-collapse:collapse;margin:20px 0}}
th{{background:#f8f9fa;padding:10px;text-align:left;border-bottom:2px solid #ddd}}
td{{padding:10px;border-bottom:1px solid #eee}}
.total{{text-align:right;font-size:1.2em;font-weight:bold;margin-top:20px}}
.footer{{margin-top:40px;color:#999;font-size:0.85em}}
</style></head><body>
<div class="header"><h1>INVOICE</h1></div>
<div class="invoice-info">
    <div><strong>Invoice #:</strong> {invoice_num}<br><strong>Date:</strong> {date_str}</div>
    <div><strong>Bill To:</strong><br>{client_name}<br>{client_email}</div>
</div>
<table>
<tr><th>Description</th><th style="text-align:center">Qty</th><th style="text-align:right">Unit Price</th><th style="text-align:right">Amount</th></tr>
{items_html}
</table>
<div class="total">Total: ${total:.2f}</div>
<div class="footer"><p>Thank you for your business!</p></div>
</body></html>"""
    return html, total

def generate_pdf(html_content, output_path):
    """Convert HTML to PDF using weasyprint or fallback."""
    try:
        from weasyprint import HTML
        HTML(string=html_content).write_pdf(output_path)
        return True
    except ImportError:
        pass
    
    # Fallback: save as HTML with .pdf extension won't work, so save HTML
    html_path = output_path.replace('.pdf', '.html')
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"  (Saved as HTML — open in browser and Print > Save as PDF)")
    print(f"  To auto-generate PDFs, install: pip install weasyprint")
    return False

def main():
    print("=" * 55)
    print("  INVOICE PDF GENERATOR")
    print("=" * 55)
    print()
    
    csv_path = input("CSV file with invoice data (drag here): ").strip().strip('"')
    if not os.path.isfile(csv_path):
        print("ERROR: File not found.")
        print("\nCSV format: client_name, client_email, item, quantity, unit_price, date, invoice_number")
        print("Example: Acme Corp,billing@acme.com,Web Design,1,500.00,2026-05-10,INV-001")
        sys.exit(1)
    
    output_dir = os.path.join(os.path.dirname(csv_path) or ".", "invoices")
    os.makedirs(output_dir, exist_ok=True)
    
    generated = 0
    total_revenue = 0
    
    with open(csv_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        invoices = {}
        for row in reader:
            inv_num = row.get('invoice_number', f"INV-{generated+1:04d}")
            if inv_num not in invoices:
                invoices[inv_num] = {
                    'client': row.get('client_name', 'Client'),
                    'email': row.get('client_email', ''),
                    'date': row.get('date', datetime.now().strftime('%Y-%m-%d')),
                    'items': []
                }
            item = row.get('item', 'Service')
            qty = int(row.get('quantity', 1))
            price = float(row.get('unit_price', 0))
            invoices[inv_num]['items'].append((item, qty, price))
    
    for inv_num, data in invoices.items():
        html, total = create_invoice_html(
            data['client'], data['email'], data['items'],
            inv_num, data['date']
        )
        output_path = os.path.join(output_dir, f"{inv_num}.pdf")
        ok = generate_pdf(html, output_path)
        print(f"  Generated: {inv_num} ({data['client']}) — ${total:.2f}")
        generated += 1
        total_revenue += total
    
    print(f"\n{generated} invoice(s) generated.")
    print(f"Total invoiced: ${total_revenue:.2f}")
    print(f"Saved to: {output_dir}")
    os.startfile(output_dir)
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
