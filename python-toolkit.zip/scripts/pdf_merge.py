"""
PDF MERGER
Combine multiple PDF files into a single PDF.
Uses PyPDF2 (included). Just select your PDFs and merge them.

Usage: Run the script, select PDF files, choose output name.
"""
import os, sys

try:
    from PyPDF2 import PdfMerger
except ImportError:
    print("Installing required library: PyPDF2")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "PyPDF2", "-q"])
    from PyPDF2 import PdfMerger

def get_pdfs():
    """Let user select PDF files."""
    folder = input("Folder containing PDFs (drag here): ").strip().strip('"')
    if not os.path.isdir(folder):
        print(f"ERROR: '{folder}' is not a valid folder.")
        sys.exit(1)
    
    pdfs = sorted([f for f in os.listdir(folder) if f.lower().endswith('.pdf')])
    if not pdfs:
        print("No PDF files found in this folder.")
        sys.exit(1)
    
    print(f"\nFound {len(pdfs)} PDF(s):")
    for i, f in enumerate(pdfs, 1):
        size_kb = os.path.getsize(os.path.join(folder, f)) / 1024
        print(f"  {i:3d}. {f} ({size_kb:.0f} KB)")
    
    print("\nEnter numbers to merge (e.g., '1-5' or '1,3,5' or 'all'):")
    selection = input("> ").strip().lower()
    
    if selection == "all":
        return [os.path.join(folder, f) for f in pdfs]
    
    # Parse selection
    indices = set()
    for part in selection.split(","):
        part = part.strip()
        if "-" in part:
            try:
                start, end = part.split("-")
                indices.update(range(int(start), int(end) + 1))
            except:
                pass
        else:
            try:
                indices.add(int(part))
            except:
                pass
    
    selected = [os.path.join(folder, pdfs[i-1]) for i in sorted(indices) if 1 <= i <= len(pdfs)]
    return selected

def main():
    print("=" * 55)
    print("  PDF MERGER")
    print("=" * 55)
    print()
    
    pdf_files = get_pdfs()
    if not pdf_files:
        print("No PDFs selected.")
        input("\nPress Enter to exit...")
        return
    
    print(f"\nMerging {len(pdf_files)} PDF(s)...")
    output_name = input("Output filename (e.g., 'combined.pdf'): ").strip()
    if not output_name.endswith('.pdf'):
        output_name += '.pdf'
    
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    output_path = os.path.join(desktop, output_name)
    
    merger = PdfMerger()
    for pdf in pdf_files:
        merger.append(pdf)
        print(f"  Added: {os.path.basename(pdf)}")
    
    merger.write(output_path)
    merger.close()
    print(f"\nMerged PDF saved to: {output_path}")
    os.startfile(desktop)  # Open folder
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
