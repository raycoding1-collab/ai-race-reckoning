# Dark Premium Template Pack

Three production-ready, dark-themed website templates. Zero dependencies, single-file HTML with embedded CSS and JavaScript. Glassmorphism, particle backgrounds, smooth scroll animations — everything your project needs to look stunning on launch day.

## What's Inside

### 1. SaaS Landing Page (`template-1-saas.html`)
- Full landing page with navigation, hero, features grid, pricing table, CTA, and footer  
- Purple/teal accent scheme with gradient text and animated ambient background  
- 6 feature cards with glassmorphism hover effects  
- 3-tier pricing table with "Popular" badge, checkmark lists  
- Fade-in scroll animations via Intersection Observer  
- Mobile responsive, fixed nav with backdrop blur  

### 2. Portfolio / Personal Brand (`template-2-portfolio.html`)
- Hero with avatar, gradient name, stats counters, dual CTA  
- Interactive particle background (mouse-attracted, 80 particles)  
- Project showcase grid with gradient placeholder images and tech tags  
- Skills section with hover-glow badges  
- Contact CTA box with gradient border  
- Purple/cyan accent scheme  

### 3. Coming Soon / Launch Page (`template-3-coming-soon.html`)
- Live countdown timer (days, hours, minutes, seconds — auto-targets 14 days out)  
- Email signup form with validation feedback  
- Grid background with radial mask and pulsing glow orb  
- Social links row  
- Pink/indigo accent scheme  
- Centered, minimal layout — perfect for pre-launch pages  

## Why This Pack

- **Zero dependencies** — no npm, no CDN, no frameworks. Open in any browser.
- **Dark theme** — modern, professional, eye-friendly. Matches 2026 design trends.
- **Glassmorphism** — the frosted-glass aesthetic that converts.
- **Responsive** — looks great on phones, tablets, and desktops.
- **Animated** — scroll-triggered reveals, particle systems, gradient ambience.
- **Copy-paste ready** — replace the placeholder text and you're live.

## Usage

1. Open any `.html` file in your browser to preview
2. Copy the file into your project
3. Replace placeholder text, colors, and content
4. Deploy

## License

Single-project commercial use included. Redistribution or resale of the template files themselves is not permitted. See full license at purchase.

---

**Price: $10.00**  
**Format: 3 HTML files + README**  
**Updated: May 2026**
